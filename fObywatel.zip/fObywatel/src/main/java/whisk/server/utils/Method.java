package whisk.server.utils;

public class Method {

    public static String POST = "POST";
    public static String GET = "GET";
    public static String PUT = "PUT";
    public static String HEAD = "HEAD";
    public static String DELETE = "DELETE";
    public static String CONNECT = "CONNECT";
    public static String OPTIONS = "OPTIONS";
    public static String TRACE = "TRACE";
    public static String PATCH = "PATCH";

}