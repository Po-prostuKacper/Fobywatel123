package whisk.utils;

public class Errors {
    public static String JSON = "There was an error while parsing JSON";
    public static String SQL = "There was an error with the database";
    public static String UNKNOWN = "There was an unknown error";
    public static String UNAUTHORIZED = "Unauthorized";
}
